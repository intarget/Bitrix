<?
$uptolike_intarget_default_option = array(
	"INTARGET_LANGUAGE" => "ru",
);
?>