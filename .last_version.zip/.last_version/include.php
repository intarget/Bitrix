<?
CModule::AddAutoloadClasses(
	"uptolike.intarget",
	array(
		"CUptolikeIntarget" => "classes/general/intarget.php",
	)
);