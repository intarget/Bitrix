<? if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arComponentDescription = array(
	"NAME"			=> GetMessage("UPTOLIKE_INTARGET_COMPONENT_NAME"),
	"DESCRIPTION"	=> GetMessage("UPTOLIKE_INTARGET_COMPONENT_DESCRIPTION"),
	"ICON" => "/images/icon.gif",
	"CACHE_PATH" => "Y",
	"PATH" => array(
		"ID" => "intarget",
	),
);
?>