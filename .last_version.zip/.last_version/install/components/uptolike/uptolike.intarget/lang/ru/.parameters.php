<?
//$MESS["UPTOLIKE_SHARE_GROUP_DATA_SOURCE"] = "Uptolike виджет";
?>