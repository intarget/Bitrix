<?
//$MESS["UPTOLIKE_SHARE"] = "Uptolike виджет";
?>