<?
$MESS["uptolike.intarget_MODULE_NAME"] = "inTarget eCommerce";
$MESS["uptolike.intarget_MODULE_DESC"] = "inTarget.ru - система аналитики для интернет-магазинов, с возможностью отслеживать продажи и анализировать конверсии в реальном времени.";
$MESS["uptolike.intarget_PARTNER_NAME"] = "inTarget";
$MESS["uptolike.intarget_PARTNER_URI"] = "http://intarget.ru/";
?>