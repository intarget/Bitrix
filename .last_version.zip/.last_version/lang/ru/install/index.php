<?
$MESS["uptolike.intarget_MODULE_NAME"] = "inTarget виджет";
$MESS["uptolike.intarget_MODULE_DESC"] = "inTarget.ru - конструктор социальных кнопок для вашего сайта с расширенным функционалом. Служба поддержки: plugins@intarget.ru";
$MESS["uptolike.intarget_PARTNER_NAME"] = "inTarget";
$MESS["uptolike.intarget_PARTNER_URI"] = "http://intarget.ru/";
?>