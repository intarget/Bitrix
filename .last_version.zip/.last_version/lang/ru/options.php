<?
$MESS["INTARGET_TAB_CONSTRUCTOR"] = "Конструктор";
$MESS["INTARGET_TAB_CONSTRUCTOR_TITLE"] = "Конструктор кнопок";

$MESS["INTARGET_TAB_SETTINGS"] = "Настройки";
$MESS["INTARGET_TAB_SETTINGS_TITLE"] = "Настройки";

$MESS["INTARGET_TAB_LANGUAGE"] = "Язык:";
$MESS["INTARGET_LANGUAGE_RU"] = "Русский";
$MESS["INTARGET_LANGUAGE_EN"] = "Английский";
$MESS["INTARGET_LANGUAGE_UA"] = "Украинский";
$MESS["INTARGET_LANGUAGE_DE"] = "Немецкий";
$MESS["INTARGET_LANGUAGE_ES"] = "Испанский";
$MESS["INTARGET_LANGUAGE_IT"] = "Итальянский";
$MESS["INTARGET_LANGUAGE_LT"] = "Латвийский";
$MESS["INTARGET_LANGUAGE_PL"] = "Польский";

$MESS["INTARGET_TAB_HORIZ_ALLIGMENT"] = "Выравнивание:";
$MESS["INTARGET_HORIZ_ALLIGMENT_LEFT"] = "По левому краю";
$MESS["INTARGET_LANGUAGE_CENTER"] = "По центру";
$MESS["INTARGET_LANGUAGE_RIGHT"] = "По правому краю";

$MESS["INTARGET_ERROR"] = "Ошибка";
$MESS["INTARGET_TAB_MAIL"] = "Email:";
$MESS["INTARGET_TAB_KEY"] = "Ключ:";
$MESS["INTARGET_TAB_WIDGET_CODE"] = "Код виджета:";
$MESS["INTARGET_TAB_WIJET_SETTINGS"] = "Настройки виджета:";

$MESS["INTARGET_TAB_MESS_1"] = "Введите ваш адрес электронной почты сервиса intarget";
$MESS["INTARGET_TAB_MESS_2"] = "Введите ваш ключ API";

$MESS["INTARGET_TAB_MESS_3"] = "Введен неверный ключ! Убедитесь что вы скопировали ключ без лишних символов (пробелов и т.д.)";
$MESS["INTARGET_TAB_MESS_4"] = "Невозможно создать проект. Возможно, он уже создан.";
$MESS["INTARGET_TAB_MESS_5"] = "Данный email не зарегистрирован на сайте http://intarget.ru";

$MESS["INTARGET_TAB_BTN_AUTORIZ"] = "Авторизация";

$MESS["INTARGET_TAB_MAIL_ILLEGAL_ARGUMENTS"] = '<span style="color:red;">Email пустой или указан неверно.</span>';
$MESS["INTARGET_TAB_MAIL_ALREADY_EXISTS"] = '<span style="color:red;">Пользователь с таким email уже зарегистрирован, обратитесь в службу поддержки: <a href="mailto:uptolikeshare@gmail.com">uptolikeshare@gmail.com</a></span>';
$MESS["INTARGET_TAB_MAIL_SENDED"] = 'На ваш адрес электронной почты отправлен секретный ключ. Введите его в поле ниже<br>Если письмо с ключом долго не приходит, возможно оно попало в Спам.<br>Если ключ так и не был получен напишите письмо в службу поддержки: <a href="mailto:uptolikeshare@gmail.com">uptolikeshare@gmail.com</a>';

$MESS["INTARGET_TAB_TEXT1"] = 'Для вывода кнопок используйте наш компонент <i><b>Uptolike виджет (uptolike:uptolike.share)</b></i>, который находится во кладке <b>комопненты</b> визуального редактора.';
$MESS["INTARGET_TAB_TEXT2"] = 'Данный модуль полностью бесплатен. Мы регулярно его улучшаем и добавляем новые функции.<br>Пожалуйста, оставьте свой отзыв на <a href="http://marketplace.1c-bitrix.ru/solutions/uptolike.share/#tab-rating-link">данной странице</a>. Спасибо!';
$MESS["INTARGET_TAB_TEXT3"] = '<a href="http://uptolike.ru">Uptolike.ru</a> - конструктор социальных кнопок для вашего сайта с расширенным функционалом.<br>Служба поддержки: <a href="mailto:uptolikeshare@gmail.com">uptolikeshare@gmail.com</a>';
$MESS["INTARGET_TAB_TEXT4"] = 'Пожалуйста, оставьте свой отзыв на <a href="http://marketplace.1c-bitrix.ru/solutions/uptolike.share/#tab-rating-link">данной странице</a>. Спасибо!';