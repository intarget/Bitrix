<?
$MESS["INTARGET_TAB_CONSTRUCTOR"] = "Конструктор";
$MESS["INTARGET_TAB_CONSTRUCTOR_TITLE"] = "Конструктор кнопок";

$MESS["INTARGET_TAB_SETTINGS"] = "Настройки";
$MESS["INTARGET_TAB_SETTINGS_TITLE"] = "Настройки";

$MESS["INTARGET_TAB_HEADER"] = "Оцените принципиально новый подход к просмотру статистики. Общайтесь со своей аудиторией, продавайте лучше, зарабатываейте больше.<br/>И всё это бесплатно!";

$MESS["INTARGET_TAB_LANGUAGE"] = "Язык:";
$MESS["INTARGET_LANGUAGE_RU"] = "Русский";

$MESS["INTARGET_ERROR"] = "Ошибка";
$MESS["INTARGET_TAB_MAIL"] = "Email:";
$MESS["INTARGET_TAB_KEY"] = "Ключ:";
$MESS["INTARGET_TAB_WIDGET_CODE"] = "Код виджета:";
$MESS["INTARGET_TAB_WIJET_SETTINGS"] = "Настройки виджета:";

$MESS["INTARGET_TAB_MESS_1"] = "Введите ваш адрес электронной почты сервиса intarget";
$MESS["INTARGET_TAB_MESS_2"] = "Введите ваш ключ API";

$MESS["INTARGET_TAB_MESS_3"] = "Введен неверный ключ! Убедитесь что вы скопировали ключ без лишних символов (пробелов и т.д.)";
$MESS["INTARGET_TAB_MESS_4"] = "Невозможно создать проект. Возможно, он уже создан.";
$MESS["INTARGET_TAB_MESS_5"] = "Данный email не зарегистрирован на сайте http://intarget.ru";
$MESS["INTARGET_TAB_MESS_6"] = "Неверный формат данных.";
$MESS["INTARGET_TAB_MESS_7"] = "Ответ от сервера inTarget не получен. Попробуйсте, пожалуйста, позднее.";

$MESS["INTARGET_TAB_BTN_AUTORIZ"] = "Авторизация";

$MESS["INTARGET_ID_SUCCESS"] = "Поздравляем, сайт успешно привязан к аккаунту <a href='https://intarget.ru'>inTarget</a>";

$MESS["INTARGET_TAB_MAIL_ILLEGAL_ARGUMENTS"] = "<span style='color:red;'>Email пустой или указан неверно.</span>";
$MESS["INTARGET_TAB_MAIL_ALREADY_EXISTS"] = "<span style='color:red;'>Пользователь с таким email уже зарегистрирован, обратитесь в службу поддержки: <a href='mailto:uptolikeshare@gmail.com'>uptolikeshare@gmail.com</a></span>";

$MESS["INTARGET_TAB_TEXT1"] = "Введите email и ключ API из личного кабинета <a href='https://intarget.ru'>inTarget.ru</a>";
$MESS["INTARGET_TAB_TEXT2"] = "Если вы ещё не зарегистрировались в сервисе inTarget это можно сделать по ссылке <a href='https://intarget.ru'>inTarget.ru</a>";
$MESS["INTARGET_TAB_TEXT3"] = "Служба технической поддержки: <a href='mailto:plugins@intarget.ru'>plugins@intarget.ru</a>";
$MESS["INTARGET_TAB_TEXT4"] = "Bitrix inTarget ver.1.0.0";