<?
define("ADMIN_MODULE_NAME", "uptolike.intarget");
IncludeModuleLangFile(__FILE__);
?>